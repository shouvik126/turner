package com.example.user.turner;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class MainActivity extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Element ele[]=new Element[20];

        //element declaration part start....................
        ele[0]=new Element();
        ele[0].ch="^";
        ele[0].next=ele[1];

        ele[1]=new Element();
        ele[1].ch=">";
        ele[1].next=ele[2];

        ele[2]=new Element();
        ele[2].ch="@";
        ele[2].next=ele[3];

        ele[3]=new Element();
        ele[3].ch="<";
        ele[3].next=ele[0];
        //element declaration part end.......................

        //Button initialization part start.....................
        Butt butt[][]=new Butt[5][5];

        butt[0][0]=new Butt();
        butt[0][0].bt=(Button)findViewById(R.id.b00) ;
        butt[0][0].fill=0;

        butt[0][1]=new Butt();
        butt[0][1].bt=(Button)findViewById(R.id.b01) ;
        butt[0][1].fill=0;

        butt[0][2]=new Butt();
        butt[0][2].bt=(Button)findViewById(R.id.b02) ;
        butt[0][2].fill=0;

        butt[0][3]=new Butt();
        butt[0][3].bt=(Button)findViewById(R.id.b03) ;
        butt[0][3].fill=0;

        butt[0][4]=new Butt();
        butt[0][4].bt=(Button)findViewById(R.id.b04) ;
        butt[0][4].fill=0;

        butt[1][0]=new Butt();
        butt[1][0].bt=(Button)findViewById(R.id.b10) ;
        butt[1][0].fill=0;

        butt[1][1]=new Butt();
        butt[1][1].bt=(Button)findViewById(R.id.b11) ;
        butt[1][1].fill=0;

        butt[1][2]=new Butt();
        butt[1][2].bt=(Button)findViewById(R.id.b12) ;
        butt[1][2].fill=0;

        butt[1][3]=new Butt();
        butt[1][3].bt=(Button)findViewById(R.id.b13) ;
        butt[1][3].fill=0;

        butt[1][4]=new Butt();
        butt[1][4].bt=(Button)findViewById(R.id.b14) ;
        butt[1][4].fill=0;

        butt[2][0]=new Butt();
        butt[2][0].bt=(Button)findViewById(R.id.b20) ;
        butt[2][0].fill=0;

        butt[2][1]=new Butt();
        butt[2][1].bt=(Button)findViewById(R.id.b21) ;
        butt[2][1].fill=0;

        butt[2][2]=new Butt();
        butt[2][2].bt=(Button)findViewById(R.id.b22) ;
        butt[2][2].fill=0;

        butt[2][3]=new Butt();
        butt[2][3].bt=(Button)findViewById(R.id.b23) ;
        butt[2][3].fill=0;

        butt[2][4]=new Butt();
        butt[2][4].bt=(Button)findViewById(R.id.b24) ;
        butt[2][4].fill=0;

        butt[3][0]=new Butt();
        butt[3][0].bt=(Button)findViewById(R.id.b30) ;
        butt[3][0].fill=0;

        butt[3][1]=new Butt();
        butt[3][1].bt=(Button)findViewById(R.id.b31) ;
        butt[3][1].fill=0;

        butt[3][2]=new Butt();
        butt[3][2].bt=(Button)findViewById(R.id.b32) ;
        butt[3][2].fill=0;

        butt[3][3]=new Butt();
        butt[3][3].bt=(Button)findViewById(R.id.b33) ;
        butt[3][3].fill=0;

        butt[3][4]=new Butt();
        butt[3][4].bt=(Button)findViewById(R.id.b34) ;
        butt[3][4].fill=0;

        butt[4][0]=new Butt();
        butt[4][0].bt=(Button)findViewById(R.id.b40) ;
        butt[4][0].fill=0;

        butt[4][1]=new Butt();
        butt[4][1].bt=(Button)findViewById(R.id.b41) ;
        butt[4][1].fill=0;

        butt[4][2]=new Butt();
        butt[4][2].bt=(Button)findViewById(R.id.b42) ;
        butt[4][2].fill=0;

        butt[4][3]=new Butt();
        butt[4][3].bt=(Button)findViewById(R.id.b43) ;
        butt[4][3].fill=0;

        butt[4][4]=new Butt();
        butt[4][4].bt=(Button)findViewById(R.id.b44) ;
        butt[4][4].fill=0;
        //Button initialization part end.......................

        //collection initialization part start...............
        List<Integer>random=new ArrayList<>();
        for(int i=0;i<=3;i++)
        {
            random.add(i);
        }

        List<Integer>rand=new ArrayList<>();
        for(int j=0;j<5;j++)
        {
            rand.add(j);
        }
        //collection initialization part end.................

        //first time 8 button initialization part start...........
        Collections.shuffle(random);
        Collections.shuffle(rand);
        butt[rand.get(0)][rand.get(1)].ch=ele[random.get(0)].ch;
        butt[rand.get(0)][rand.get(1)].bt.setText((String)butt[rand.get(0)][rand.get(1)].ch);
        butt[rand.get(0)][rand.get(1)].fill=1;
        //first timr 8 button initialization part end..............

        //Randomize part start.......................

        //Randomize part end.........................

    }
}
