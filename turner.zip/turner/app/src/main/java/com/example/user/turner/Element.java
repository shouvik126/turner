package com.example.user.turner;

public class Element {
    String ch;
    Element next;
}
